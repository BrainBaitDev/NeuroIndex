# Changelog

All notable changes to NeuroIndex will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial public release
- Multi-core sharded architecture (16 shards)
- RESP protocol support (Redis-compatible)
- HTTP REST API
- Cuckoo hash table for O(1) point lookups
- Adaptive Radix Tree (ART) wrapper for range queries
- Cuckoo Filter for membership testing
- Sharded WAL (Write-Ahead Log) with 16 parallel writers
- Compressed snapshots with zstd
- Crash recovery with partial recovery support
- SQL query engine (SELECT, WHERE, ORDER BY, LIMIT, aggregations)
- TTL (Time-To-Live) support
- Pub/Sub messaging system
- Secondary indexes (value and prefix)
- Tag system for atomic associations
- Geospatial indexes (radius queries, K-NN)
- Resource limits and eviction policies (LRU, LFU, Random, VolatileLRU)
- Metrics collection and observability
- Background non-blocking snapshots
- Rate limiting
- 23 example applications
- Client libraries (Python, Go, Node.js, .NET, Rust)
- 18 shell scripts for testing and demos
- Comprehensive documentation (28 markdown files)

### Performance
- GET operations: ~80M ops/sec (16 cores estimated)
- PUT operations: ~30M ops/sec (16 cores estimated)
- Latency: <200ns (GET p50), <1µs (GET p99)
- Sharded WAL: 27K ops/sec write throughput
- Recovery: <1 second for 100K+ keys

### Documentation
- Complete README with architecture overview
- Production readiness guide
- Quick start guide
- REST API examples
- Academic references
- Benchmark results
- Contributing guidelines

## [0.1.0] - 2025-01-XX

### Initial Release
- Core database engine with sharding
- Basic persistence (WAL + snapshots)
- RESP protocol server
- HTTP REST API server
- Interactive CLI client

---

## Version Numbering

- **MAJOR**: Incompatible API changes
- **MINOR**: New features (backwards-compatible)
- **PATCH**: Bug fixes (backwards-compatible)

## Release Process

1. Update version in `Cargo.toml` files
2. Update `CHANGELOG.md` with release notes
3. Create git tag: `git tag -a v0.1.0 -m "Release v0.1.0"`
4. Push tag: `git push origin v0.1.0`
5. Create GitHub release with binaries
6. Publish to crates.io (if applicable)

---

For older releases, see [GitHub Releases](https://github.com/yourusername/neuroindex/releases).
