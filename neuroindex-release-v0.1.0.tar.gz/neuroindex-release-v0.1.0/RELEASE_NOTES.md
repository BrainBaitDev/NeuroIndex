# 🚀 NeuroIndex v0.1.0 - First Stable Release

**NeuroIndex** is a high-performance in-memory database written in Rust, designed as a multi-core alternative to Redis.

## 🎯 Highlights

- **Multi-Core Native**: Lock-free sharded architecture (16 parallel shards)
- **Dual Protocol**: RESP (Redis-compatible) + HTTP REST API
- **Advanced Indexing**: Cuckoo Hashing, Adaptive Radix Tree (BTreeMap), Hopscotch Hashing, Cuckoo Filter
- **Robust Persistence**: Sharded WAL + compressed snapshots
- **SQL Support**: Full SQL-like query engine
- **Enterprise Ready**: TTL, Pub/Sub, Geospatial, Metrics, Resource Limits

## 📦 Installation

### Debian/Ubuntu via APT Repository
```bash
# Add repository
echo "deb [trusted=yes] https://BrainBaitDev.github.io/NeuroIndex/debian stable main" | sudo tee /etc/apt/sources.list.d/neuroindex.list

# Install
sudo apt update
sudo apt install neuroindex
```

### Direct Download
Download the `.deb` package from the Assets section below.

```bash
sudo dpkg -i neuroindex_0.1.0-1_amd64.deb
```

## 🔧 Quick Start

```bash
# Start RESP server (Redis-compatible)
sudo systemctl start neuroindex-resp

# Start HTTP server
sudo systemctl start neuroindex-http

# Test with CLI
neuroindex-cli

# Configuration
sudo nano /etc/neuroindex/config.toml
```

## ⚡ Performance

| Metric | Value |
|--------|-------|
| **Throughput** | ~5M ops/sec per core |
| **Latency (p50)** | <200ns |
| **Latency (p99)** | <1µs |
| **WAL Write** | 27K ops/sec |
| **Recovery** | <1s for 100K+ keys |

## ✨ Key Features

### Core Capabilities
- ✅ Key-Value Operations (GET, SET, DELETE, MGET, MSET)
- ✅ Range Queries with ART-based indexing
- ✅ Secondary Indexes (tags, values, prefixes)
- ✅ Cuckoo Filter for probabilistic membership testing
- ✅ Atomic operations with lock-free concurrency

### SQL Query Engine
```sql
SELECT * FROM kv WHERE key BETWEEN 'user:0' AND 'user:9' LIMIT 10
SELECT COUNT(*) FROM kv WHERE value LIKE 'pattern%'
UPDATE kv SET value = '{"new": "data"}' WHERE key = 'user:123'
DELETE FROM kv WHERE key BETWEEN 'session:0' AND 'session:999'
```

### Enterprise Features
- 🕐 **TTL (Time-To-Live)**: Automatic key expiration
- 📢 **Pub/Sub**: Topic-based messaging with pattern matching
- 🌍 **Geospatial**: Radius queries, K-nearest neighbors
- 📊 **Metrics**: Real-time stats and observability
- 💾 **Persistence**: Sharded WAL + compressed snapshots
- 🔄 **Crash Recovery**: Robust partial recovery

## 📚 Architecture

### Multi-Shard Lock-Free Design
Each shard contains:
- **Memory Arena**: Efficient allocation with epoch-based GC
- **CuckooTable**: O(1) key-value lookups
- **ArtTree**: Range queries and prefix searches (BTreeMap backend)
- **HopscotchMap**: Tag, value, and prefix indexing
- **CuckooFilter**: Probabilistic existence checks

### Persistence Layer
- **Sharded WAL**: 16 parallel write-ahead logs with zstd compression
- **Snapshots**: Non-blocking background serialization
- **Recovery**: Snapshot + WAL replay for full restoration

## 📋 What's Included

**Binaries:**
- `neuroindex-server` - Main server binary
- `neuroindex-resp-server` - RESP protocol server
- `neuroindex-http-server` - HTTP REST API server
- `neuroindex-cli` - Command-line client

**Services:**
- `neuroindex-resp.service` - RESP server systemd unit
- `neuroindex-http.service` - HTTP server systemd unit

**Configuration:**
- `/etc/neuroindex/config.toml` - Main configuration file

## 📖 Documentation

- [GitHub Repository](https://github.com/BrainBaitDev/NeuroIndex)
- [Architecture Documentation](https://github.com/BrainBaitDev/NeuroIndex/blob/main/md/architettura%20interna.pdf)
- [Quick Start Guide](https://github.com/BrainBaitDev/NeuroIndex#quick-start)

## 🔗 Links

- **Homepage**: https://github.com/BrainBaitDev/NeuroIndex
- **APT Repository**: https://BrainBaitDev.github.io/NeuroIndex
- **Issues**: https://github.com/BrainBaitDev/NeuroIndex/issues

## 📦 Package Details

- **Version**: 0.1.0-1
- **Architecture**: amd64
- **Size**: 4.0 MB
- **License**: Apache-2.0
- **Maintainer**: BrainBaitDev <antonio@brainbait.it>

## 🙏 Credits

Built with Rust 🦀 and love ❤️ by the NeuroIndex team.

---

**Full Changelog**: First stable release
