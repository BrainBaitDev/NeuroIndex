# 📦 GUIDA PUBBLICAZIONE NEUROINDEX v0.1.0

## ✅ STATO ATTUALE
- [x] Pacchetto DEB compilato: `target/debian/neuroindex_0.1.0-1_amd64.deb` (4.0 MB)
- [x] Repository APT preparato in `gh-pages/`
- [x] Metadata aggiornati con BrainBaitDev

---

## 🚀 PASSO 1: COMMIT E PUSH

```bash
cd /area51/neuroindex

# Aggiungi tutti i file
git add .

# Commit
git commit -m "Release v0.1.0 - First stable release

- High-performance in-memory database
- Multi-shard lock-free architecture
- Dual protocol (RESP + HTTP)
- Sharded WAL + compressed snapshots
- SQL query engine
- Enterprise features (TTL, Pub/Sub, Geospatial)
"

# Push
git push origin main
```

---

## 🏷️ PASSO 2: CREA TAG VERSIONE

```bash
# Crea tag annotato
git tag -a v0.1.0 -m "Release v0.1.0 - First Stable Release"

# Push del tag
git push origin v0.1.0
```

---

## 📦 PASSO 3: CREA GITHUB RELEASE

### Via Web Interface:

1. **Vai alla pagina releases**:
   ```
   https://github.com/BrainBaitDev/NeuroIndex/releases/new
   ```

2. **Compila i campi**:
   - **Choose a tag**: Seleziona `v0.1.0`
   - **Release title**: `NeuroIndex v0.1.0 - First Stable Release`
   - **Description**: Copia da `RELEASE_NOTES.md` (vedi sotto)

3. **Upload Assets**:
   - Clicca "Attach binaries by dropping them here"
   - Trascina: `target/debian/neuroindex_0.1.0-1_amd64.deb`

4. **Opzioni**:
   - ✅ Set as the latest release
   - ❌ Set as a pre-release

5. **Clicca**: "Publish release"

### Download diretto per utenti:
```bash
wget https://github.com/BrainBaitDev/NeuroIndex/releases/download/v0.1.0/neuroindex_0.1.0-1_amd64.deb
sudo dpkg -i neuroindex_0.1.0-1_amd64.deb
```

---

## 🌐 PASSO 4: PUBBLICA GITHUB PAGES (APT REPO)

### A. Verifica contenuto gh-pages

```bash
cd /area51/neuroindex
ls -R gh-pages/debian/

# Output atteso:
# gh-pages/debian/
# ├── dists/stable/main/binary-amd64/
# │   ├── Packages
# │   └── Packages.gz
# └── pool/main/
#     └── neuroindex_0.1.0-1_amd64.deb (4.0 MB)
```

### B. Commit gh-pages

```bash
git add gh-pages/
git commit -m "Update APT repository - v0.1.0"
git push origin main
```

### C. Abilita GitHub Pages

1. Vai su: `https://github.com/BrainBaitDev/NeuroIndex/settings/pages`

2. **Source**:
   - Branch: `main`
   - Folder: `/gh-pages`

3. Clicca **Save**

4. Aspetta 1-2 minuti per il deploy

5. Verifica su: `https://BrainBaitDev.github.io/NeuroIndex/`

### D. Installazione per utenti

Gli utenti possono ora installare con:

```bash
# Aggiungi repository
echo "deb [trusted=yes] https://BrainBaitDev.github.io/NeuroIndex/debian stable main" | sudo tee /etc/apt/sources.list.d/neuroindex.list

# Aggiorna e installa
sudo apt update
sudo apt install neuroindex

# Verifica
neuroindex-server --version
```

---

## 🎯 COMANDI RAPIDI (Tutto in uno)

```bash
# 1. Commit tutto
cd /area51/neuroindex
git add .
git commit -m "Release v0.1.0 - First stable release"
git push origin main

# 2. Tag
git tag -a v0.1.0 -m "Release v0.1.0"
git push origin v0.1.0

# 3. Poi vai su GitHub web per creare la Release e abilitare Pages
```

---

## ✅ CHECKLIST FINALE

- [ ] Commit e push codice
- [ ] Tag v0.1.0 creato e pushato
- [ ] GitHub Release creata
- [ ] File .deb caricato come asset
- [ ] GitHub Pages abilitato
- [ ] Repository APT funzionante
- [ ] Testato: `apt update && apt install neuroindex`

---

## 🔗 LINK UTILI

- **Repository**: https://github.com/BrainBaitDev/NeuroIndex
- **Releases**: https://github.com/BrainBaitDev/NeuroIndex/releases
- **APT Repo**: https://BrainBaitDev.github.io/NeuroIndex/
- **Settings Pages**: https://github.com/BrainBaitDev/NeuroIndex/settings/pages
