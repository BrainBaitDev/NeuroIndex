# NeuroIndex APT Repository

This repository is automatically generated and hosts the NeuroIndex .deb packages.

Visit https://BrainBaitDev.github.io/neuroindex/ for installation instructions.
